# TNG Quick Alert (projek Android)

Aplikasi contoh yang membaca **notifikasi Facebook yang Android tunjukkan** dan mengesan pautan `links.tngdigital.com.my/moneypacket/...`. Ia kemudian membuat notifikasi khas. Tekan notifikasi itu untuk membuka pautan; tekan Claim sendiri dalam TNG.

## Batasan penting
- Ia **bukan APK siap pasang**; ini ialah projek sumber Android Studio.
- Ia hanya boleh mengesan pautan jika Facebook memasukkan pautan penuh dalam kandungan notifikasi. Facebook kadangkala menyembunyikan/meringkaskan kandungan group, jadi pengesanan mungkin tidak berlaku.
- Ia tidak membaca semua mesej group di dalam Facebook, tidak mengakses akaun, dan tidak menekan Claim secara automatik.

## Cara bina APK
1. Muat turun dan ekstrak ZIP ini pada komputer.
2. Pasang Android Studio dari laman rasmi Android Developers.
3. Android Studio → **Open** → pilih folder `TNGQuickAlert` yang diekstrak.
4. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35.
5. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`. Pindahkan ke telefon dan pasang.

## Cara aktifkan pada telefon
1. Buka TNG Quick Alert.
2. Tekan **Benarkan notifikasi aplikasi**.
3. Tekan **Hidupkan Notification Access**.
4. Dalam tetapan Android, hidupkan akses untuk **TNG Quick Alert** dan sahkan.
5. Pastikan notifikasi Facebook untuk group berkenaan dihidupkan.

Untuk menguji, minta seseorang menghantar pautan Money Packet dalam group dan lihat sama ada pautan penuh muncul dalam notifikasi Facebook. Jika tidak muncul, aplikasi ini tidak dapat mengesannya dengan kaedah ini.
