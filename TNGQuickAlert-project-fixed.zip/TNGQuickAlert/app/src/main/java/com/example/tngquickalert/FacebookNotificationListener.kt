package com.example.tngquickalert

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class FacebookNotificationListener : NotificationListenerService() {
    private val channelId = "tng_money_packet_alerts"
    private val pattern = Regex("https?://links\\.tngdigital\\.com\\.my/moneypacket/[A-Za-z0-9_-]+(?:\\?[^\\s]+)?", RegexOption.IGNORE_CASE)

    override fun onListenerConnected() {
        super.onListenerConnected()
        createChannel()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg != "com.facebook.katana" && pkg != "com.facebook.lite") return
        val extras = sbn.notification.extras ?: return
        val candidates = mutableListOf<String>()
        listOf(Notification.EXTRA_TITLE, Notification.EXTRA_TEXT, Notification.EXTRA_BIG_TEXT, Notification.EXTRA_SUB_TEXT, Notification.EXTRA_SUMMARY_TEXT).forEach { key ->
            extras.getCharSequence(key)?.toString()?.let { candidates.add(it) }
        }
        extras.getParcelableArray(Notification.EXTRA_MESSAGES)?.forEach { item ->
            if (Build.VERSION.SDK_INT >= 24 && item is android.app.Notification.MessagingStyle.Message) {
                item.text?.toString()?.let { candidates.add(it) }
            }
        }
        val allText = candidates.joinToString(" ")
        val link = pattern.find(allText)?.value ?: return
        val prefs = getSharedPreferences("seen_links", MODE_PRIVATE)
        val previous = prefs.getString("last_link", null)
        if (previous == link) return
        prefs.edit().putString("last_link", link).apply()
        showAlert(link)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(channelId, "Pautan Money Packet TNG", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Makluman apabila pautan Money Packet TNG dikesan dalam notifikasi Facebook"
            })
        }
    }

    private fun showAlert(link: String) {
        createChannel()
        val openIntent = Intent(Intent.ACTION_VIEW, Uri.parse(link)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        val pending = PendingIntent.getActivity(this, link.hashCode(), openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Pautan Money Packet TNG dikesan")
            .setContentText("Tekan untuk buka pautan TNG")
            .setStyle(Notification.BigTextStyle().bigText("Pautan dikesan daripada notifikasi Facebook. Tekan untuk buka TNG / pautan. Claim masih perlu ditekan sendiri."))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(Notification.PRIORITY_HIGH)
            .build()
        getSystemService(NotificationManager::class.java).notify(link.hashCode(), notification)
    }
}
